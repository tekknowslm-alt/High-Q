<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Inward</title>
</head>
<%
   String mode=request.getParameter("mode");
   String code=request.getParameter("code");
   String userId=(String)session.getAttribute("LOGIN_ID");
   String branch=request.getParameter("branch");
   String screenCode=request.getParameter("screencode");
%>
<body>
	<input type="hidden" id="prevreportid" value=""/>
	<div class="col-sm-12 col-md-12 col-lg-12 mpZero  marTp" id="heading">
		<div class="col-md-12 col-sm-12 marLfBx panelOrange hcH">
			Bought Note
			<span class="pull-right"><button class="btn btn-sm" onclick="backToMainReport();" id="repback" style="display:none"><i class="fa fa-arrow-up"></i></span></div>
			</div>
	</div>    

	<div class="col-md-12 col-sm-12 mpZero ">
		<div class="col-md-12 col-sm-12 mpZero">
			<div class="col-md-12 col-sm-12 marLfBx panelOrange hcH">
				<div class="col-md-12 col-sm-12 mpZero">
					<div class="clearfix"></div>
					<div class="col-md-12 col-sm-12 mpZero">
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>Date</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="bn_date">									
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>Bought Note No.</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="bn_no">
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-sm-12 mpZero">
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>Vendor Name</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="ledger_name">
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>Sticker Code</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="sticker_code">
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-sm-12 mpZero">
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>DC No.</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="dc_no">
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 mpZero">
							<div class="form-group mbotto">
								<div class="col-md-3">
									<label>DC Date</label>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" id="dc_date">
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 col-sm-12 marLfBx panelOrange hcH">
					<div class="col-md-12 col-sm-12 mpZero" id="bnotegrid"
						style="height: 350px">
						<span>Warping Grid<span /> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br>
					</div>
				</div>
				
			</div>
			<div id="saveGrp" class="">
				<span id="actionbuttons">
					<div class="col-sm-2 col-md-2 col-lg-2 adCl"
						onclick="clearInnerScreen()">Clear</div>
					<div class="col-sm-2 col-md-2 col-lg-2 adCl saVbN"
						onclick="saveRewindingIssue()">Save</div>
					<div class="col-sm-2 col-md-2 col-lg-2 adCl"
						onclick="editRewindingIssue()">Edit</div>
					<div class="col-sm-2 col-md-2 col-lg-2 adCl"
						onclick="cancelRewindingIssue()">Delete</div>
				</span>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
				<%--div style="background:#fedc34; display:inline-block; width:100%; padding:5px 10px">
		    		<div class="netAm" id="netAmt">Net Amount 0.00</div>
		    		<div class="col-md-4 colBg2 mpZero"><div class="col-md-6">Disc</div><div class="col-md-6" id="disc">0.00</div></div>
		    		<div class="col-md-4 colBg2 mpZero"><div class="col-md-6">VAT</div><div class="col-md-6" id="vat">0.00</div></div>
		    		<div class="col-md-4 colBg2 mpZero"><div class="col-md-6">Total</div><div class="col-md-6" id="totamt">0.00</div></div>
	    		</div--%>
			</div>
		</div>
		<script>
    var sProps={js:"",screen:[
    {name:"group1",predesigned:true,contentType:"Fields",
    fields:[{name:"code",inputType:0,type:"INT",caption:"",mandatory:false,defaultValue:"0","maxValue":0,"textLength":10,"decimalLength":0,"visible":false,"readOnly":true,"chkTag":false,nf:"girtype"},
  	{name:"bn_date",inputType:0,type:"DATE",caption:"",mandatory:false,defaultValue:"","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":false,nf:"suppliername"},
  	{name:"bn_no",inputType:0,type:"INT",caption:"",mandatory:false,defaultValue:"1","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":false,nf:"suppliername"},
  	{name:"ledger_code",inputType:0,type:"INT",caption:"",mandatory:false,defaultValue:"0","maxValue":0,"textLength":10,"decimalLength":0,"visible":false,"readOnly":true,"chkTag":false,nf:"ordered_by"},  	
 	{name:"ledger_name",inputType:0,type:"LOV",caption:"",mandatory:true,defaultValue:"","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":true,nf:"ordered_by",lovOptions:{url:"/kannika/service/ajax",ajax:"ledger_list_both",scrollEnabled:true,searchFromList:false,dsi:0,params:[],results:[
  	{tgt:"ledger_name",tt:false,id:"ledger_name"},
  	{tgt:"ledger_name",tt:true,id:"ledger_name"},
  	{tgt:"ledger_code",tt:false,id:"ledger_code"}
    ]},validation:""}, 	
    {name:"sticker_code",inputType:0,type:"TEXT",caption:"",mandatory:false,defaultValue:"","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":false,nf:"suppliername"},
	{name:"dc_no",inputType:0,type:"TEXT",caption:"",mandatory:false,defaultValue:"1","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":false,nf:"suppliername"},
  	{name:"dc_date",inputType:0,type:"DATE",caption:"",mandatory:false,defaultValue:"","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"chkTag":false,nf:"suppliername"},
	  
	{name:"btnSave",inputType:3,caption:"",visible:false},
    {name:"btnClear",inputType:3,caption:"",visible:false}
  	]},
  	{name:"bnotegrid",title:"",contentType:"Table",tableProperties:{rowObject:true,serialNumberColumn:"sno",rowEmptyCheckColumn:"product_code1",optional:false,columns:[
    {order:"0",id: "sno", name: "SNo", field: "sno",defaultValue:"0","inputType":0,"type":"INT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":true,"mandatory":true,"chkTag":false,width:50,sno:true},
    {order:"1",id: "product_code1", name: "product_code1", field: "product_code1",defaultValue:"0","inputType":0,"type":"INT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":true,"mandatory":true,width:0,"chkTag":false},    
    {order:"2",id: "prod_code1", name: "Our Code", field: "prod_code1",defaultValue:"0","inputType":0,"type":"LOV","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"mandatory":true,width:100,"chkTag":true,lovOptions:{url:"/kannika/service/ajax",ajax:"products",scrollEnabled:true,searchFromList:false,dsi:0,params:[],results:[
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"product_code",col:"product_code1"},
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"product_code",col:"product_code2"},
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"prod_code",col:"prod_code1"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"prod_code",col:"prod_code1"},
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"prod_code",col:"prod_code2"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"prod_code",col:"prod_code2"},
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"product_name",col:"product_name"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"product_name",col:"product_name"},	
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"unit_code",col:"unit_code"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"unit_code",col:"unit_code"},	
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"unit_name",col:"unit_name"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"unit_name",col:"unit_name"},  	
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"hsn_code",col:"hsn_code"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"hsn_code",col:"hsn_code"},    	
    	]},validation:"onProductCodeChange"},
	{order:"3",id: "product_code2", name: "product_code2", field: "product_code2",defaultValue:"0","inputType":0,"type":"INT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":true,"mandatory":true,width:0,"chkTag":false,onchange:"onProductCodeChange"},    
    {order:"4",id: "prod_code2", name: "Vendor Code", field: "prod_code2",defaultValue:"0","inputType":0,"type":"LOV","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,"mandatory":true,width:100,"chkTag":true,lovOptions:{url:"/kannika/service/ajax",ajax:"products",scrollEnabled:true,searchFromList:false,dsi:0,params:[],results:[
      	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"product_code",col:"product_code2"}, 
      	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"prod_code",col:"prod_code2"},
      	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"prod_code",col:"prod_code2"},
      	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"product_name",col:"product_name"},
      	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"product_name",col:"product_name"},
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"unit_code",col:"unit_code"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"unit_code",col:"unit_code"},	
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"unit_name",col:"unit_name"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"unit_name",col:"unit_name"},    	
    	{tgt:"bnotegrid_data",tt:false,row:"cr",id:"hsn_code",col:"hsn_code"},
    	{tgt:"bnotegrid_data",tt:true,row:"cr",id:"hsn_code",col:"hsn_code"},
      	]},validation:"onProductCodeChange"},
	{order:"5",id: "product_name", name: "Product Name", field: "product_name",defaultValue:"0","inputType":0,"type":"TEXT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":true,"mandatory":true,width:300,align:"left","chkTag":false,onchange:"onRateQuantityChange"},
	{order:"6",id: "hsn_code", name: "HSN", field: "hsn_code",defaultValue:"0","inputType":0,"type":"TEXT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":true,"mandatory":true,width:100,align:"center","chkTag":false,onchange:"onRateQuantityChange"},
	{order:"7",id: "rate", name: "Rate", field: "rate",defaultValue:"0","inputType":0,"type":"DECI","maxValue":0,"textLength":10,"decimalLength":2,"visible":true,"readOnly":false,"mandatory":false,width:125,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    {order:"8",id: "qty", name: "Quantity", field: "qty",defaultValue:"0","inputType":0,"type":"INT","maxValue":0,"textLength":10,"decimalLength":0,"visible":true,"readOnly":false,cTotal:true,"mandatory":false,width:125,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    {order:"9",id: "mtrs", name: "Mtrs", field: "mtrs",defaultValue:"0","inputType":0,"type":"DECI","maxValue":0,"textLength":10,"decimalLength":2,"visible":true,"readOnly":false,cTotal:true,"mandatory":false,width:125,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    {order:"10",id: "unit_code", name: "UnitCode", field: "unit_code",defaultValue:"0","inputType":0,"type":"INT","maxValue":0,"textLength":10,"decimalLength":0,"visible":false,"readOnly":false,"mandatory":true,width:0,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    {order:"11",id: "unit_name", name: "Unit", field: "unit_name",defaultValue:"0","inputType":0,"type":"TEXT","maxValue":0,"textLength":10,"decimalLength":0,"visible":false,"readOnly":true,"mandatory":true,width:50,align:"center","chkTag":false,cTotal:true,onchange:"onRateQuantityChange"},
    {order:"12",id: "amount", name: "Amount", field: "amount",defaultValue:"0","inputType":0,"type":"DECI","maxValue":0,"textLength":10,"decimalLength":2,"visible":false,"readOnly":true,cTotal:true,"mandatory":false,width:125,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    {order:"13",id: "rate1", name: "rate1", field: "rate1",defaultValue:"0","inputType":0,"type":"DECI","maxValue":0,"textLength":10,"decimalLength":2,"visible":false,"readOnly":true,cTotal:true,"mandatory":false,width:0,align:"right","chkTag":false,onchange:"onRateQuantityChange"},
    ]
    }}]};
    var gir=new FlexUI.Screen("warpbreaks",sProps);
	<%@ include file = "drilldown.jsp" %>
	//ajax columns
	var showTender=true;
	
	var l=new FlexUI.Ajax();
    $(document).ready(function () {
            screenObjects.getScreenObject("bnotegrid_data").getInputField().onTextKeyDown.subscribe(tableTextKeyDown);
            screenObjects.getScreenObject("bnotegrid_data").onAfterDeleteRow.subscribe(tableRowDelete);
            //screenObjects.getScreenObject("girtype").focus();
      loadInwardNo();
      
  	if("<%=code%>"!="" && "<%=code%>"!="null"){
   		debugger
		onEditClose(undefined,undefined,<%=code%>)
	}	    
   
      
        });
        
        function saveRewindingIssue(){
        	if('<%=mode%>'=="View") return;
        	if(gir.getSaveInProgress()) return;
        	var r=null;
        	var cnt;
			var a=new FlexUI.Ajax();
	       	var r=a.callAjax("GET","/kannika/service/ajax?id=fincheck&ro=false&ic=0&tdate="+screenObjects.getScreenObject("bn_date").getValue());	    
	       	if(r!=null){
	   	 			if(r.data){
	   	 				cnt=r.data[0][0];	
									if(cnt==0)
										{
										alert("Please Check Finance Period...");
										return;
										}
	    						}
						    
				  }
    		var code=screenObjects.getScreenObject("code").getValue();
    		if(code=="" || code=="0"){ 
    			gir.setOperation("ADD");
        	}
        	else
        		{
        		var txt;
				if(gir.getOperation()=="MOD")
				{
				txt="Confirm to Modify";		
				}
				else
				{
				txt="Confirm to Delete";
				}
        		var r = confirm(txt);
        		if (r != true) {
        		  return;        		  
        		}         		
        		}
    		

    		gir.setScreenCode("600048");
    		var d=gir.processDataToSave();
    		gir.setSaveInProgress(true);    		
			if("FAILED"!=d){
				var s=new FlexUI.Ajax();
				showLoader();
				r=s.callAjax("POST","/kannika/service/screen/save",d);
				hideLoader();
		 	}else{
		 		alert("Please correct the validation errors and continue...");
		 		gir.setSaveInProgress(false);		 		
		 		return;
		 	}		 
		 	if(r.result=="Success"){
				alert(r.message+" [No:"+r.code+"]");
				clearInnerScreen();
				return r.code;			
			}else{
				gir.setSaveInProgress(false);
				alert(r.message);		
			}
        }
                 function loadInwardNo()
                 {
					  var a=new FlexUI.Ajax();
					  var r=a.callAjax("GET","/kannika/service/ajax?id=bn_no&ro=false&ic=0");
 	 				 if(r!=null){
   	 						if(r.data){
   	 							screenObjects.getScreenObject("bn_no").setValue(r.data[0][0]);	
    									}
							    }	
				  }
        
        function onGirTypeChange(id,me){
        	//var gt=screenObjects.getScreenObject("girtype").getValue();
        	//screenObjects.getScreenObject("girprefix").setValue("H"+gt);
        	return true;
        }
        function clearInnerScreen(){
        	gir.clearScreen();
        	gir.setSaveInProgress(false);
        	onGirTypeChange();
        	if("<%=mode%>"=="View"){
        		$('.ui-dialog').children().remove();
				$('.ui-dialog').remove();
				$("#bodyContainer").children().remove();
				$("#bodyContainer").html("");
				$("#bodyContainer").load("/kannika/billPrintRequest.do?id=11&title=Bills");
        	}
        	screenObjects.getScreenObject("bn_date").focus();
	        loadInwardNo();
        }
        function onRateQuantityChange(id,me){
			var t=me.getParent();
			calculateTotal();
			return true;
		}
        function onProductCodeChange(id,me){
        	    var a=new FlexUI.Ajax();
           		var productcode;
             	var t=screenObjects.getScreenObject("bnotegrid_data");
				var cols=t.getCols();
				var prev_rate=0;
				var s=t.getSize();
				var net_amount=0;
				for(var i=0;i<s;i++){
			 	if(t.getCurrentRow()==i )
			  {
			  productcode=t.getText(i,cols.product_code1);
			  prev_rate=t.getText(i,cols.rate1);
			  
		 	 var r=a.callAjax("GET","/kannika/service/ajax?id=purc_rate_list_b&ro=false&ic=0&productcode="+productcode+"&ledger="+screenObjects.getScreenObject("ledger_code").getValue());
		 
			if(r!=null){  
				if(r.data){		
					if(r.data[0][0]>0 && toNumber(prev_rate)==0){
 					t.setText(i,cols.rate,r.data[0][0]);} 
				}
			}
			}
			} 
			return true;
		}
		function calculateTotal(){
			var total=0,amt=0,rate=0,amount=0;
			var total_cones=0;
			var t=screenObjects.getScreenObject("bnotegrid_data");
			var cols=t.getCols();
			var s=t.getSize();
			var net_amount=0;
			for(var i=0;i<s;i++){
				//total_cones=toNumber(t.getText(i,cols.bags))* toNumber(t.getText(i,cols.cones_bag));
				//t.setText(i, cols.cones,total_cones);
			qty=toNumber(t.getText(i,cols.qty));
			mtrs=toNumber(t.getText(i,cols.mtrs));
			rate=toNumber(t.getText(i,cols.rate));
			if(t.getText(i,cols.unit_code)=="1")
				{
				amount=roundOff(qty*rate,2);
				}
			else
				{
				amount=roundOff(mtrs*rate,2);
				}
				t.setText(i,cols.amount,amount);
			}
		}
		function tableTextKeyDown(e,args){
			var key=e.which || e.keyCode;
			if(key==113){
				e.preventDefault();
				saveRewindingIssue();
			}
		}
		function tableRowDelete(e,args){
			calculateTotal();
		}
		function loadRewindingIssue(url,code,did){
		  	showLoader();
			var l=new FlexUI.Ajax();
			var v=l.callAjax("GET",url,"");
			gir.loadObjectData(v);
			calculateTotal();
			hideLoader();
		}
		function onEditClose(e,args,rcode)
		{	
			var a=new FlexUI.Ajax();
			showLoader();
			if(!rcode){
				rcode=args.result[8];
			}
			var r=a.callAjax("GET","/kannika/service/screen/data?screencode=600048","code="+rcode);
			clearInnerScreen();
			clearInterval();
			gir.setOperation("MOD");
			gir.loadObjectData(r);
			hideLoader();
			calculateTotal();
		}
		function editRewindingIssue(id,me){
			gir.setOperation("MOD");
			var l={url:"/kannika/service/ajax",ajax:"bought_note_list",scrollEnabled:true,searchFromList:false,dsi:1,params:[],results:[{tgt:"code",id:"0",tt:false}],closeFunction:"onEscClose"};
			var lov=new FlexUI.LOV("e_lov",me,l);
			lov.onLovClose.subscribe(onEditClose);
			lov.show();
			}
		function onCancelClose(e,args)
		{	
			//screenObjects.getScreenObject(gir.getInitialFocus()).focus();
			var a=new FlexUI.Ajax();
			showLoader();
			var r=a.callAjax("GET","/kannika/service/screen/data?screencode=600048","code="+args.result[8]);
			clearInnerScreen();
			gir.setOperation("CAN");
			gir.loadObjectData(r);
			calculateTotal();
			hideLoader();
		}
		function cancelRewindingIssue(id,me){
			gir.setOperation("CAN");	
			var l={url:"/kannika/service/ajax",ajax:"bought_note_list",scrollEnabled:true,searchFromList:false,dsi:1,params:[],results:[{tgt:"code",id:"0",tt:false}],closeFunction:"onEscClose"};
			var lov=new FlexUI.LOV("e_lov",me,l);
			lov.onLovClose.subscribe(onCancelClose);
			lov.show();
			}	
	</script>
</body>
</html>